# UXPulse - Customer UX Feedback & Usability Testing Platform

Build a modern, high-impact web application that allows product managers, UX researchers, and founders to create shareable test URLs, guide customers through specific website tasks, collect quantitative metrics and qualitative feedback, and analyze UX insights in an analytics dashboard.

## User Review Required

> [!IMPORTANT]
> The app includes both the **Researcher Admin Portal** (for creating tests and viewing analytics) and the **Customer Test Runner** (the live URL experience customers see when invited to test a site).
>
> We will pre-populate 2-3 realistic sample usability campaigns (with real responses and metrics) so you can immediately explore analytics, while also being able to create your own custom URLs and take tests in real time.

## Proposed Architecture & Features

### 1. Customer Test Experience (`/test/:id` or Shareable Link)
- **Welcome Briefing**: Warm intro, estimated duration, device requirement notice.
- **Split-Screen Usability Test Runner**:
  - **Left Guide Panel**: Current step instructions, task progress counter, timer, task completion confirmation, optional friction log.
  - **Right Site Canvas**: Responsive iframe preview of target URL with desktop/mobile viewport toggle and fallback interactive canvas.
- **Post-Task Questionnaire**:
  - **Quantitative Metrics**:
    - Single Ease Question (SEQ: 1 to 7 rating scale)
    - Net Promoter Score (NPS: 0 to 10 rating scale)
    - System Usability Scale (SUS) quick score
    - Task Completion Status & Difficulty Rating
  - **Qualitative Metrics**:
    - "What was the most confusing part?"
    - "What feature or text would improve your experience?"
    - General comments & optional contact/role info
- **Instant Response Submission**: Saves feedback to persistent storage and updates analytics live.

### 2. Campaign Builder Studio
- Title, Description, and Target URL configuration.
- Flexible Task Builder (Add step title, description, success condition).
- Custom Question Builder (Rating scales, multi-choice, open text).
- One-Click Shareable Link & QR Code generator.

### 3. Researcher Analytics & UX Insights Hub
- **Executive Summary Dashboard**:
  - Task Completion Rate (%)
  - Average SEQ (Single Ease Question) & SUS Scores
  - Customer Net Promoter Score (NPS)
  - Avg Time on Task
- **Visual Analytics**:
  - Task-by-task completion & drop-off breakdown chart
  - NPS & Ease Score distribution graphs
- **Qualitative Feedback & Sentiment Engine**:
  - Filterable customer response feed (by rating, sentiment, completion status)
  - Keyword tagging & Friction Heatmap summary (e.g. #CheckoutDelay, #ConfusingCTA, #NavigationIssue)
  - Individual session drill-down inspector

---

## Proposed Component Structure

```text
uxpulse-app/
├── index.html
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   ├── index.css               # Design system, glassmorphism tokens, custom gradients
│   ├── context/
│   │   └── CampaignContext.jsx # Global state & LocalStorage persistence
│   ├── components/
│   │   ├── Navigation.jsx      # Top header with mode switcher (Dashboard / Tester View)
│   │   ├── admin/
│   │   │   ├── CampaignList.jsx       # Overview of active shareable test links
│   │   │   ├── CampaignBuilder.jsx    # Create/Edit usability campaign & tasks
│   │   │   ├── AnalyticsDashboard.jsx # Quantitative KPIs, charts & metric cards
│   │   │   └── FeedbackFeed.jsx       # Qualitative feedback list & participant modal
│   │   ├── tester/
│   │   │   ├── WelcomeScreen.jsx      # Tester onboarding
│   │   │   ├── TestRunner.jsx         # Split-screen workspace with tasks & iframe
│   │   │   ├── FeedbackSurvey.jsx     # Quantitative rating scales & qualitative text fields
│   │   │   └── ThankYouScreen.jsx     # Completion confirmation
│   │   └── common/
│   │       ├── Card.jsx, Button.jsx, Modal.jsx, RatingStars.jsx, Badge.jsx
│   └── data/
│       └── mockData.js         # Pre-loaded usability campaigns & tester responses
```

---

## Verification Plan

### Automated Tests & Checks
- Build check: `npm run build` / `vite build`
- Dev server execution: `npm run dev`

### Manual Verification
1. Launch campaign builder, create a new UX test with 3 tasks and 2 questions, and generate a shareable test link.
2. Open the generated test link as a tester, navigate tasks, mark tasks complete, fill out post-task survey (NPS, CSAT, qualitative text), and submit.
3. Switch back to Admin Analytics to verify live update of KPIs, charts, and qualitative feedback entry.
