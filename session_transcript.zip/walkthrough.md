# UXPulse - Customer Usability & Feedback Platform Walkthrough

We built and deployed **UXPulse**, a complete customer feedback and usability testing web platform that enables product creators, UX researchers, and founders to create shareable test links, guide customers step-by-step through website tasks, and collect quantitative and qualitative UX metrics.

## 🚀 Key Features Implemented

### 1. Left Drawer Search & Sorting Options 🔍
- Added a **Sort by** dropdown in the left navigation drawer with two active sorting modes:
  - 🕒 **Most Recent**: Sorts campaigns chronologically by creation timestamp (`createdAt`).
  - 📊 **Most Responses**: Sorts campaigns dynamically by participant submission count (`responses.length`).
- Search input filters campaign title and ID live, working seamlessly alongside status tabs (**All**, **Active**, **Archived**) and sort controls.

### 2. Expanded Mock Usability Campaigns 📋
- Includes 7 diverse usability testing campaigns for thorough navigation testing:
  1. `camp-001`: **Checkout & Payment Flow Usability Test** (Active, 3 Responses)
  2. `camp-002`: **SaaS Dashboard Onboarding & Navigation Audit** (Active, 1 Response)
  3. `camp-003`: **Mobile Banking App - Loan Calculator Usability** (Active, 1 Response)
  4. `camp-004`: **E-Learning Platform - Course Enrollment & Video Player** (Active, 0 Responses)
  5. `camp-005`: **Healthcare Portal - Doctor Appointment Booking** (Archived, 0 Responses)
  6. `camp-006`: **AI Writing Assistant - Prompt Customization Flow** (Active, 0 Responses)
  7. `camp-007`: **Travel Booking - Multi-City Flight & Hotel Search** (Active, 0 Responses)

### 3. Royal Blue Primary Buttons with Sesame Orange Accents 👑🍊
- **UXPulse Logo & Profile Avatar**: Both the UXPulse activity logo badge and the user profile avatar icon (`UX`) use OpenSesame's **Sesame Orange** gradient (`#FF5A00` -> `#FF7300`).
- **Primary Buttons & Gradients**: Premium **Royal Blue** (`#1D4ED8` -> `#2563EB` -> `#3B82F6`) for primary CTAs (`+ Create New Campaign`, `Begin Usability Test`, active tab pills).

### 4. End & Archive Campaign Lifecycle 📦
- **Archive Action**: Clicking **"End & Archive"** (`Archive` icon) in the campaign view or sidebar drawer prompts confirmation and sets campaign status to `archived`.
- **Status Badges & Sidebar Filters**: Displays `Active` (orange) vs `Archived` (amber) status badges.

### 5. Title Inline Edit & Delete Controls ✍️
- Placed **Edit** (`Pencil` icon), **End & Archive** (`Archive` icon), and **Delete** (`Trash2` icon) buttons inline right next to the active campaign title.

### 6. Dedicated Delete Confirmation Modal 🚨
- Custom glassmorphism **Delete Confirmation Modal** (`DeleteConfirmModal.jsx`) displaying campaign name, ID, and exact count of collected customer response logs that will be removed.

---

## 🛠️ How to Test & Access

1. **Development Server**: Running live at `http://localhost:3002`
2. **Sort Testing**: Open the left drawer, toggle **Sort by:** between **Most Recent** and **Most Responses**, and observe `camp-001` (3 responses) jump to the top!
